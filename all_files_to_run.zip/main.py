from os import path

from Solution import Board, Futoshiki_Solver

# Naama Omer 207644014, Moshe Zeev Hefter 205381379


# MAIN.PY CODE FILE:

# This is the main program, it has no auxiliary methods, and its purpose is to manage the input receipt
# process, and run the appropriate objects to arrive to valid solution with calculation for the inserted input panel.
if __name__ == '__main__':

    # input receive from user:
    # this path will lead us to all txt files with boards to solve.
    PATH_TO_TXT_FILE = input(
        "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n             HELLO!\n    WELCOME TO FUTOSHIKI SOLVER!\n"
        "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
        "Please enter PATH to a .txt file, with a list of paths"
        "to Futoshiki boards to solve\n"
        "An example of the outer .txt file:\n\n"
        "./inputs/5_easy.txt\n./inputs/5_tricky.txt\n./inputs/6_easy.txt"
        "\n./inputs/6_tricky.txt\n./inputs/7_easy.txt\n./inputs/7_tricky.txt\n\nPath:")
    # Check for input:
    # if PATH exists:
    assert path.exists(PATH_TO_TXT_FILE), "Path don't exist"
    # if PATH is to a file:
    assert path.isfile(PATH_TO_TXT_FILE), "Path dose not directed to file"
    # if the file is from type txt
    assert PATH_TO_TXT_FILE.endswith('.txt'), "path is not a text type file"
    # if the path pass all checks:
    # getting the second input from user (a number between 1-3, include)
    alg_code = input("Please press 1 - For regular evolutionary algorithm.\n"
                     "Please press 2 - For Darwin strategy with the evolutionary algorithm.\n"
                     "Please press 3 - For Lamarck strategy with the evolutionary algorithm.\n"
                     "Answer:\n")

    # now we open the main file - with all paths written inside - line py line:
    # we don't check if succeed because of the checks above - it is seems enough
    with open(PATH_TO_TXT_FILE, 'r') as fp:
        # initialize counter of files:
        count = 0
        # start main func:
        print("\nLet's go!")
        # go over lines in txt file:
        for line in fp:
            # reduce the /n from line name
            line = line[:-1]
            # print status
            print("Working on file " + str(count + 1) + "# in path: '" + line[:-1] + "' ...")
            # initialize arrays:
            iter_array = []
            average_score_array = []
            best_score_array = []
            # Creat the first object - board object:
            board_current_level = Board(line)
            # Creat the object Futoshiki_Solver which initialize the first 100 set of boards - generation 0
            a = Futoshiki_Solver(board_current_level)

            # if regular alg- selection():
            if alg_code == '1':
                # do the first crossover in call to selection method (in type like alg_code inserted) of Futoshiki_
                # Solver object a
                a.selection()
                # 'i' is the number of generations - for print and analyze - start with 0 so the next will be 1
                i = 1
                # loop until we got a solution with score 0 - which means is legal solution for problem,
                # or while we on the first time
                while not a.evaluations[0] == 0 or i == 1:
                    # a new Generation call:
                    a.selection()
                    # always check after reaching to new genetation - if there is a new board born to be the chosen
                    if a.evaluations[0] == 0:
                        # if yes - print the status and also the final board:
                        print("Total Generations number: ", i, ", Best score: ", a.evaluations[0],
                              ", Average score: ", sum(a.evaluations) / 100)
                        # update arrays:
                        best_score_array.append(a.evaluations[0])
                        average_score_array.append(sum(a.evaluations) / 100)
                        iter_array.append(i)
                        # and succeed:
                        print("\nWe have reached a solution!\n")
                        # the final board print:
                        print(a.solutions[0].board)
                        # break the loop.
                        break
                    # else - keep going:

                    # ***** MUTATION CONTROLLER *******
                    if i < 1000:
                        a.mutation()
                    else:
                        if a.evaluations[0] == 1 and i < 2000:
                            a.mutation(0.1)
                        else:
                            a.mutation(p=0.02)
                    # *********************************

                    # every 100 generation passed:
                    if i % 100 == 0:
                        # we want to write the status for user on screen
                        print("Generation number: ", i, ", Best score: ", a.evaluations[0],
                              ", Average score: ", sum(a.evaluations) / 100)

                        #  and also to add the updated data into the lists/arrays:
                        best_score_array.append(a.evaluations[0])
                        average_score_array.append(sum(a.evaluations) / 100)
                        iter_array.append(i)

                    # if we have reached to 5000 generations - we will stop the alg on the current board:
                    if i >= 5000:
                        # and print the best board we have reached - (with the best score)
                        print(
                            "\nSorry, solution not found :(\nThis is the best solution after 5,000 generations:\n")
                        print(a.solutions[0].board)
                        # stop loop:
                        break
                    # add 1 to i
                    i += 1

            # elif Darwin alg- selection_Darwin():
            elif alg_code == '2':
                # do the first crossover in call to selection method (in type like alg_code inserted) of Futoshiki_
                # Solver object a
                a.selection_Darwin()
                # 'i' is the number of generations - for print and analyze - start with 0 so the next will be 1
                i = 1
                # loop until we got a solution with score 0 - which means is legal solution for problem,
                # or while we on the first time
                while not a.evaluations[0] == 0 or i == 1:
                    # a new Generation call:
                    a.selection_Darwin()
                    # always check after reaching to new genetation - if there is a new board born to be the chosen
                    if a.evaluations[0] == 0:
                        # if yes - print the status and also the final board:
                        print("Total Generations number: ", i, ", Best score: ", a.evaluations[0],
                              ", Average score: ", sum(a.evaluations) / 100)
                        # update arrays:
                        best_score_array.append(a.evaluations[0])
                        average_score_array.append(sum(a.evaluations) / 100)
                        iter_array.append(i)
                        # and succeed:
                        print("\nWe have reached a solution!\n")
                        # the final board print:
                        print(a.solutions[0].board)
                        # break the loop.
                        break
                    # else - keep going:

                    # ***** MUTATION CONTROLLER *******
                    if i < 1000:
                        a.mutation()
                    else:
                        if a.evaluations[0] == 1 and i < 2000:
                            a.mutation(0.1)
                        else:
                            a.mutation(p=0.02)
                    # *********************************

                    # every 100 generation passed:
                    if i % 100 == 0:
                        # we want to write the status for user on screen
                        print("Generation number: ", i, ", Best score: ", a.evaluations[0],
                              ", Average score: ", sum(a.evaluations) / 100)

                        #  and also to add the updated data into the lists/arrays:
                        best_score_array.append(a.evaluations[0])
                        average_score_array.append(sum(a.evaluations) / 100)
                        iter_array.append(i)

                    # if we have reached to 5000 generations - we will stop the alg on the current board:
                    if i >= 5000:
                        # and print the best board we have reached - (with the best score)
                        print(
                            "\nSorry, solution not found :(\nThis is the best solution after 5,000 generations:\n")
                        print(a.solutions[0].board)
                        # stop loop:
                        break
                    # add 1 to i
                    i += 1

            # elif Lamarck alg- selection_Lamarck():
            elif alg_code == '3':
                # do the first crossover in call to selection method (in type like alg_code inserted) of Futoshiki_
                # Solver object a
                a.selection_Lamarck()
                # 'i' is the number of generations - for print and analyze - start with 0 so the next will be 1
                i = 1
                # loop until we got a solution with score 0 - which means is legal solution for problem,
                # or while we on the first time
                while not a.evaluations[0] == 0 or i == 1:
                    # a new Generation call:
                    a.selection_Lamarck()
                    # always check after reaching to new genetation - if there is a new board born to be the chosen
                    if a.evaluations[0] == 0:
                        # if yes - print the status and also the final board:
                        print("Total Generations number: ", i, ", Best score: ", a.evaluations[0],
                              ", Average score: ", sum(a.evaluations) / 100)
                        # update arrays:
                        best_score_array.append(a.evaluations[0])
                        average_score_array.append(sum(a.evaluations) / 100)
                        iter_array.append(i)
                        # and succeed:
                        print("\nWe have reached a solution!\n")
                        # the final board print:
                        print(a.solutions[0].board)
                        # break the loop.
                        break
                    # else - keep going:

                    # ***** MUTATION CONTROLLER *******
                    if i < 1000:
                        a.mutation()
                    else:
                        if a.evaluations[0] == 1 and i < 2000:
                            a.mutation(0.1)
                        else:
                            a.mutation(p=0.02)
                    # *********************************

                    # every 100 generation passed:
                    if i % 100 == 0:
                        # we want to write the status for user on screen
                        print("Generation number: ", i, ", Best score: ", a.evaluations[0],
                              ", Average score: ", sum(a.evaluations) / 100)

                        #  and also to add the updated data into the lists/arrays:
                        best_score_array.append(a.evaluations[0])
                        average_score_array.append(sum(a.evaluations) / 100)
                        iter_array.append(i)

                    # if we have reached to 5000 generations - we will stop the alg on the current board:
                    if i >= 5000:
                        # and print the best board we have reached - (with the best score)
                        print(
                            "\nSorry, solution not found :(\nThis is the best solution after 5,000 generations:\n")
                        print(a.solutions[0].board)
                        # stop loop:
                        break
                    # add 1 to i
                    i += 1

            # code of alg is invalid!
            else:
                raise AssertionError(alg_code + ": Code is invalid!")

        print("Finished with " + alg_code + "for all files received.")
