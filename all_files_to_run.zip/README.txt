
_______________README________________________________________________________________________________________

From the zip we uploded to git, download it, unzip it, and from now all what you need is in this folder :)
inside you can see: 
main.py - this is the code to run on cmd/other platform.
exe file - which is ready to run with double click.
_______________________________________________________________________
if you want to run the main.py code:
*make sure that the furtuer are in the same PATH as the main.py:
1. Solution.py - supplyed with the files
2. all.txt- file that we added with the files
3. inner folder named "inputs" - there you have the examples on which we build the report.

to run:
in this folder - click on the URL and instead of the path write cmd + click enter.
in the black window cmd write: main.py and enter
and the program will start running.
in "Path: _____" you can write "all.txt" with out the Apostrophes.
and in "Answer:____" insert 1,2 or 3- to chose between strategies 
and thats it!
_______________________________________________________________________
if you want to run via exe:
*make sure all files written up is in same path as the exe.

to run:
just click twice on the exe file, 
and the program will start running.
in "Path: _____" you can write "all.txt" with out the Apostrophes.
and in "Answer:____" insert 1,2 or 3- to chose between strategies 
and thats it!
_______________________________________________________________________

In general - the algorithm is giving you an option to insert input of txt with board to solve,
and he will over on each board to solve one by another.
